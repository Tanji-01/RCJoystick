package com.shoaib.rccontroller;

import android.app.*;
import android.os.*;
import android.bluetooth.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.UUID;

public class MainActivity extends Activity {
    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private OutputStream out;
    private TextView status, directionValue, throttleValue, steeringValue, speedValue, modeValue;
    private volatile boolean connected=false, driveActive=false;
    private volatile int throttle=180, leftNow=0, rightNow=0;
    private final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private final int BG=Color.rgb(5,12,18), PANEL=Color.rgb(10,24,31), CYAN=Color.rgb(0,225,238), GREEN=Color.rgb(0,235,105), MUTED=Color.rgb(145,170,180);
    private final Handler driveHandler=new Handler(Looper.getMainLooper());
    private final Runnable heartbeat=new Runnable(){public void run(){if(driveActive&&connected){send(leftNow,rightNow);driveHandler.postDelayed(this,150);}}};

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(1024,1024);getWindow().setNavigationBarColor(BG);adapter=BluetoothAdapter.getDefaultAdapter();buildUI();}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private GradientDrawable bg(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),stroke);return d;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private TextView center(String s,int size,int color){TextView t=text(s,size,color);t.setGravity(Gravity.CENTER);return t;}
    private TextView pill(String s){TextView t=center(s,11,CYAN);t.setPadding(dp(12),0,dp(12),0);t.setBackground(bg(Color.rgb(8,34,41),20,CYAN));return t;}
    private void buildUI(){
        LinearLayout root=col();root.setPadding(dp(15),dp(8),dp(15),dp(8));root.setBackgroundColor(BG);
        LinearLayout header=row();header.setGravity(Gravity.CENTER_VERTICAL);
        Logo logo=new Logo(this);header.addView(logo,lp(42,42));
        LinearLayout brand=col();TextView name=text("APEX",23,Color.WHITE);name.setTypeface(null,1);TextView sub=text("RC  /  CONTROL SYSTEM",9,CYAN);brand.addView(name);brand.addView(sub);LinearLayout.LayoutParams bp=lp(170,-2);bp.leftMargin=dp(8);header.addView(brand,bp);
        TextView nav=pill("CONTROL     •     TELEMETRY     •     SETTINGS");header.addView(nav,new LinearLayout.LayoutParams(0,dp(34),1));
        status=center("● OFFLINE",12,Color.rgb(255,110,110));status.setPadding(dp(12),0,dp(12),0);status.setBackground(bg(PANEL,18,Color.rgb(35,75,83)));header.addView(status,lp(142,36));
        Button connect=button("CONNECT",CYAN,Color.BLACK);connect.setOnClickListener(v->pairedDevices());LinearLayout.LayoutParams cp=lp(112,38);cp.leftMargin=dp(8);header.addView(connect,cp);root.addView(header,lp(-1,48));

        LinearLayout content=row();content.setGravity(Gravity.FILL);LinearLayout.LayoutParams contentP=lp(-1,-1);contentP.topMargin=dp(8);root.addView(content,contentP);
        // Left: analog joystick
        LinearLayout left=panel();left.addView(section("ANALOG DRIVE"),lp(-1,25));
        Joystick stick=new Joystick(this);left.addView(stick,new LinearLayout.LayoutParams(-1,0,1));
        TextView hint=center("DRAG TO STEER  •  RELEASE TO STOP",9,MUTED);left.addView(hint,lp(-1,24));
        content.addView(left,new LinearLayout.LayoutParams(0,-1,1.02f));

        // Center: live speed, throttle, modes, stop
        LinearLayout middle=col();middle.setPadding(dp(9),0,dp(9),0);
        LinearLayout metrics=row();
        metrics.addView(metric("SPEED","—","km/h"),new LinearLayout.LayoutParams(0,dp(64),1));
        metrics.addView(metric("BATTERY","—","sensor required"),new LinearLayout.LayoutParams(0,dp(64),1));
        middle.addView(metrics);
        SpeedGauge gauge=new SpeedGauge(this);middle.addView(gauge,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout readings=row();readings.setBackground(bg(PANEL,13,Color.rgb(20,72,81)));readings.setPadding(dp(8),dp(4),dp(8),dp(4));
        LinearLayout tv=col();tv.addView(text("THROTTLE",10,MUTED));throttleValue=text("0%",19,CYAN);tv.addView(throttleValue);readings.addView(tv,new LinearLayout.LayoutParams(0,-2,1));
        View divider=new View(this);divider.setBackgroundColor(Color.rgb(30,75,82));readings.addView(divider,lp(1,38));
        LinearLayout sv=col();sv.setPadding(dp(10),0,0,0);sv.addView(text("STEERING",10,MUTED));steeringValue=text("CENTER",19,CYAN);sv.addView(steeringValue);readings.addView(sv,new LinearLayout.LayoutParams(0,-2,1));middle.addView(readings,lp(-1,55));
        LinearLayout modes=row();modes.setPadding(0,dp(7),0,dp(7));
        modes.addView(modeButton("ECO",100),new LinearLayout.LayoutParams(0,dp(34),1));
        modes.addView(modeButton("NORMAL",180),new LinearLayout.LayoutParams(0,dp(34),1));
        modes.addView(modeButton("SPORT",255),new LinearLayout.LayoutParams(0,dp(34),1));middle.addView(modes);
        Button stop=button("■   EMERGENCY STOP",Color.rgb(190,35,48),Color.WHITE);stop.setTextSize(15);stop.setOnClickListener(v->stopAll());middle.addView(stop,lp(-1,48));
        directionValue=center("COMMAND  •  IDLE",10,MUTED);middle.addView(directionValue,lp(-1,22));
        content.addView(middle,new LinearLayout.LayoutParams(0,-1,1.18f));

        // Right: D-pad and power slider
        LinearLayout right=panel();right.addView(section("DIRECTION PAD"),lp(-1,25));
        LinearLayout pad=col();pad.setGravity(Gravity.CENTER);pad.addView(dpadButton("▲","FWD"),lp(68,48));
        LinearLayout sides=row();sides.addView(dpadButton("◀","LEFT"),lp(68,48));Button stopSmall=button("●",Color.rgb(150,35,48),Color.WHITE);stopSmall.setOnClickListener(v->stopAll());sides.addView(stopSmall,lp(52,45));sides.addView(dpadButton("▶","RIGHT"),lp(68,48));pad.addView(sides);
        pad.addView(dpadButton("▼","BACK"),lp(68,48));
        LinearLayout.LayoutParams padP=lp(-1,0);padP.height=0;padP.weight=1;right.addView(pad,padP);
        right.addView(section("POWER LIMIT"),lp(-1,24));LinearLayout power=row();speedValue=center("70%",13,CYAN);power.addView(speedValue,lp(48,32));SeekBar seek=new SeekBar(this);seek.setMax(100);seek.setProgress(70);seek.setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN));seek.setThumbTintList(android.content.res.ColorStateList.valueOf(CYAN));seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean u){throttle=Math.round(p*2.55f);speedValue.setText(p+"%");}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});power.addView(seek,new LinearLayout.LayoutParams(0,dp(35),1));right.addView(power);
        TextView foot=center("HC-05  /  CLASSIC BLUETOOTH SPP",9,MUTED);right.addView(foot,lp(-1,22));content.addView(right,new LinearLayout.LayoutParams(0,-1,1.02f));
    }
    private LinearLayout panel(){LinearLayout p=col();p.setPadding(dp(9),dp(7),dp(9),dp(7));p.setBackground(bg(PANEL,17,Color.rgb(20,72,81)));return p;}
    private TextView section(String s){TextView t=text(s,10,CYAN);t.setTypeface(null,1);return t;}
    private View metric(String title,String value,String note){LinearLayout c=col();c.setGravity(Gravity.CENTER);c.setBackground(bg(PANEL,12,Color.rgb(20,72,81)));c.addView(center(title,9,MUTED));TextView v=center(value,23,Color.WHITE);v.setTypeface(null,1);c.addView(v);c.addView(center(note,8,MUTED));return c;}
    private Button button(String s,int color,int tc){Button b=new Button(this);b.setText(s);b.setTextColor(tc);b.setTextSize(11);b.setAllCaps(false);b.setPadding(dp(5),0,dp(5),0);b.setBackground(bg(color,12,color));return b;}
    private Button modeButton(String s,int p){Button b=button(s,Color.rgb(14,39,47),s.equals("NORMAL")?CYAN:Color.WHITE);b.setTextSize(9);b.setOnClickListener(v->{throttle=p;speedValue.setText(Math.round(p/2.55f)+"%");});return b;}
    private Button dpadButton(String glyph,String cmd){Button b=button(glyph,Color.rgb(17,42,52),Color.WHITE);b.setTextSize(22);b.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){drive(cmd);return true;}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){stopAll();return true;}return true;});return b;}
    private void drive(String cmd){int p=throttle,l=0,r=0;if(cmd.equals("FWD")){l=p;r=p;}else if(cmd.equals("BACK")){l=-p;r=-p;}else if(cmd.equals("LEFT")){l=-p;r=p;}else if(cmd.equals("RIGHT")){l=p;r=-p;}leftNow=l;rightNow=r;driveActive=true;directionValue.setText("COMMAND  •  "+cmd);send(l,r);driveHandler.removeCallbacks(heartbeat);driveHandler.postDelayed(heartbeat,150);updateReadings();}
    private void updateReadings(){if(throttleValue!=null)throttleValue.setText(Math.round((Math.abs(leftNow)+Math.abs(rightNow))*50f/255f)+"%");if(steeringValue!=null){String s=leftNow==rightNow?"CENTER":leftNow<rightNow?"LEFT":"RIGHT";steeringValue.setText(s);}}
    private void stopAll(){driveActive=false;driveHandler.removeCallbacks(heartbeat);leftNow=rightNow=0;if(directionValue!=null)directionValue.setText("COMMAND  •  IDLE");if(throttleValue!=null)throttleValue.setText("0%");if(steeringValue!=null)steeringValue.setText("CENTER");send(0,0);}
    private void pairedDevices(){if(adapter==null){toast("Bluetooth is not available on this device");return;}if(!adapter.isEnabled()){startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),10);return;}try{Set<BluetoothDevice> set=adapter.getBondedDevices();if(set==null||set.isEmpty()){toast("Pair HC-05 in Android Bluetooth settings first (PIN 1234 or 0000)");return;}ArrayList<BluetoothDevice> list=new ArrayList<>(set);String[] names=new String[list.size()];for(int i=0;i<list.size();i++)names[i]=(list.get(i).getName()==null?"Bluetooth device":list.get(i).getName())+"  •  "+list.get(i).getAddress();new AlertDialog.Builder(this).setTitle("Select paired HC-05").setItems(names,(d,w)->connect(list.get(w))).setNegativeButton("Cancel",null).show();}catch(SecurityException e){toast("Allow Bluetooth permission in Android settings");}}
    private void connect(final BluetoothDevice device){status.setText("● CONNECTING");status.setTextColor(Color.YELLOW);new Thread(()->{BluetoothSocket s=null;try{if(socket!=null)socket.close();s=device.createRfcommSocketToServiceRecord(SPP);adapter.cancelDiscovery();s.connect();socket=s;out=s.getOutputStream();connected=true;send(0,0);runOnUiThread(()->{status.setText("● CONNECTED");status.setTextColor(GREEN);toast("Connected to "+device.getName());});}catch(Exception e){connected=false;try{if(s!=null)s.close();}catch(Exception ignored){}runOnUiThread(()->{status.setText("● OFFLINE");status.setTextColor(Color.rgb(255,110,110));toast("Connection failed. Check HC-05 pairing.");});}}).start();}
    private synchronized void send(int l,int r){if(!connected||out==null)return;try{out.write((l+","+r+"\n").getBytes("US-ASCII"));out.flush();}catch(Exception e){connected=false;driveActive=false;driveHandler.removeCallbacks(heartbeat);runOnUiThread(()->{status.setText("● OFFLINE");status.setTextColor(Color.rgb(255,110,110));});}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onPause(){super.onPause();stopAll();}
    @Override protected void onDestroy(){stopAll();connected=false;driveHandler.removeCallbacksAndMessages(null);try{if(socket!=null)socket.close();}catch(Exception ignored){}super.onDestroy();}

    private class Logo extends View{Paint p=new Paint(3);Logo(Context c){super(c);}protected void onDraw(Canvas c){float w=getWidth(),h=getHeight(),cx=w/2,cy=h/2,r=Math.min(w,h)*.46f;p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(8,38,47));c.drawCircle(cx,cy,r,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(CYAN);c.drawCircle(cx,cy,r,p);p.setStrokeWidth(dp(3));p.setStrokeJoin(Paint.Join.ROUND);p.setStyle(Paint.Style.STROKE);Path a=new Path();a.moveTo(cx-r*.48f,cy+r*.35f);a.lineTo(cx,cy-r*.42f);a.lineTo(cx+r*.48f,cy+r*.35f);c.drawPath(a,p);c.drawLine(cx-r*.23f,cy+r*.04f,cx+r*.23f,cy+r*.04f,p);p.setStyle(Paint.Style.FILL);p.setColor(GREEN);c.drawCircle(cx+r*.58f,cy-r*.55f,dp(2.5f),p);}}
    private class SpeedGauge extends View{Paint p=new Paint(3);SpeedGauge(Context c){super(c);}protected void onDraw(Canvas c){super.onDraw(c);float cx=getWidth()/2f,cy=getHeight()*.78f,r=Math.min(getWidth()*.38f,getHeight()*.72f);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(13));p.setStrokeCap(Paint.Cap.ROUND);p.setColor(Color.rgb(28,55,62));c.drawArc(cx-r,cy-r,cx+r,cy+r,180,180,false,p);p.setColor(CYAN);c.drawArc(cx-r,cy-r,cx+r,cy+r,180,0,false,p);p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setColor(Color.WHITE);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(dp(27));c.drawText("—",cx,cy-dp(3),p);p.setTextSize(dp(12));p.setColor(MUTED);c.drawText("km/h  •  ENCODER REQUIRED",cx,cy+dp(19),p);}}
    private class Joystick extends View{Paint p=new Paint(3);float dx,dy,cx,cy,r;Joystick(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}protected void onDraw(Canvas c){super.onDraw(c);cx=getWidth()/2f;cy=getHeight()/2f;r=Math.max(dp(35),Math.min(getWidth(),getHeight())*.34f);p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(15,42,50));c.drawCircle(cx,cy,r,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(3));p.setColor(CYAN);c.drawCircle(cx,cy,r,p);p.setStrokeWidth(dp(1));p.setColor(Color.rgb(50,91,98));c.drawLine(cx-r*.7f,cy,cx+r*.7f,cy,p);c.drawLine(cx,cy-r*.7f,cx,cy+r*.7f,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(0,170,190));c.drawCircle(cx+dx,cy+dy,r*.29f,p);p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(dp(11));c.drawText("DRAG",cx,cy+r+dp(19),p);}
        public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){float x=e.getX()-cx,y=e.getY()-cy,d=(float)Math.hypot(x,y);if(d>r){x=x*r/d;y=y*r/d;}dx=x;dy=y;invalidate();float f=-y/r,t=x/r;int l=Math.round(Math.max(-1,Math.min(1,f+t))*throttle),rr=Math.round(Math.max(-1,Math.min(1,f-t))*throttle);leftNow=l;rightNow=rr;driveActive=true;send(l,rr);driveHandler.removeCallbacks(heartbeat);driveHandler.postDelayed(heartbeat,150);directionValue.setText("COMMAND  •  JOYSTICK");updateReadings();return true;}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){dx=dy=0;invalidate();stopAll();return true;}return true;}}
}
