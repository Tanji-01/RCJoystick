#include <SoftwareSerial.h>
// HC-05 TX -> D10; HC-05 RX <- D11 through a voltage divider
SoftwareSerial bluetooth(10, 11);
const int ENA=5, IN1=2, IN2=3, IN3=4, IN4=7, ENB=6;
String input=""; unsigned long lastCommandMs=0; const unsigned long FAILSAFE_MS=700;
void motor(int pwm,int a,int b,int en){pwm=constrain(pwm,-255,255);if(pwm>0){digitalWrite(a,HIGH);digitalWrite(b,LOW);}else if(pwm<0){digitalWrite(a,LOW);digitalWrite(b,HIGH);}else{digitalWrite(a,LOW);digitalWrite(b,LOW);}analogWrite(en,abs(pwm));}
void stopCar(){motor(0,IN1,IN2,ENA);motor(0,IN3,IN4,ENB);}
void setup(){pinMode(ENA,OUTPUT);pinMode(IN1,OUTPUT);pinMode(IN2,OUTPUT);pinMode(ENB,OUTPUT);pinMode(IN3,OUTPUT);pinMode(IN4,OUTPUT);stopCar();bluetooth.begin(9600);lastCommandMs=millis();}
void loop(){while(bluetooth.available()){char c=bluetooth.read();if(c=='\n'){int k=input.indexOf(',');if(k>0){motor(input.substring(0,k).toInt(),IN1,IN2,ENA);motor(input.substring(k+1).toInt(),IN3,IN4,ENB);lastCommandMs=millis();}input="";}else if(c!='\r'&&input.length()<16)input+=c;}if(millis()-lastCommandMs>FAILSAFE_MS)stopCar();}
