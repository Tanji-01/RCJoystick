RC JOYSTICK - AIDE PROJECT

This is a Java (not Kotlin) Android project intended to be easier to open in AIDE.

AIDE steps:
1. Extract the ZIP to internal storage.
2. In AIDE choose Open Project and select the RCJoystick_AIDE folder.
3. Let AIDE import/sync the Gradle project.
4. Use the top Play/Run button to build and install. Do NOT run ./gradlew; this ZIP intentionally has no Gradle wrapper.

If AIDE asks for a Gradle version, choose a version supported by your installed AIDE. If it cannot sync Android Gradle Plugin 4.2.2, share the exact error.

Bluetooth:
1. Pair HC-05 in Android Bluetooth settings. PIN is usually 1234 or 0000.
2. Open app, tap CONNECT HC-05, select HC-05.
3. Move joystick. Release or press Emergency Stop to stop.

Arduino wiring:
HC-05 VCC->5V, GND->GND, TXD->D10, RXD->D11 through voltage divider.
L298N ENA->D5, IN1->D2, IN2->D3, IN3->D4, IN4->D7, ENB->D6.
Connect motor supply to L298N motor power input and share GND with Arduino.
Remove ENA/ENB jumpers if using PWM pins. Never power motors from Arduino 5V.
Upload Arduino_RC_Car.ino to Uno.

Safety: test with wheels lifted. Bluetooth control is not a certified safety system.
