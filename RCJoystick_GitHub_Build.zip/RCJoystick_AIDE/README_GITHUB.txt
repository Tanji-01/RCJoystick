BUILD APK ON GITHUB (NO PC)

1. Create/sign in to a free GitHub account.
2. Create a NEW PUBLIC or PRIVATE repository named RCJoystick.
3. In the repository, use Add file > Upload files and upload the PROJECT CONTENTS (not the ZIP itself), preserving folders. The repository root must contain build.gradle, settings.gradle, app/, gradle.properties, and .github/workflows/build-apk.yml.
4. Commit the upload to main.
5. Open the repository's Actions tab. Select "Build RC Joystick APK" if prompted, then wait for the run to finish with a green check.
6. Open the successful run, scroll to Artifacts, and download RCJoystick-debug-apk.
7. Extract the downloaded artifact ZIP on your phone. Install app-debug.apk.

The workflow builds a debug APK with Gradle 6.7.1 and JDK 11. It does not require gradlew in the project.
