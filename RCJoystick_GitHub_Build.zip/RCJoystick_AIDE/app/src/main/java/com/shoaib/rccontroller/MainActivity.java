package com.shoaib.rccontroller;

import android.app.*;
import android.os.*;
import android.bluetooth.*;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private OutputStream out;
    private TextView status;
    private Joystick joystick;
    private volatile boolean connected = false;
    private final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(1024,1024);
        adapter = BluetoothAdapter.getDefaultAdapter();
        makeUI();
    }

    private void makeUI() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,12,20,12); root.setBackgroundColor(Color.rgb(8,13,23));
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this); title.setText("RC  /  JOYSTICK"); title.setTextColor(Color.WHITE); title.setTextSize(23); title.setTypeface(Typeface.DEFAULT_BOLD);
        status = new TextView(this); status.setText("● DISCONNECTED"); status.setTextColor(Color.LTGRAY); status.setTextSize(13);
        Button connect = new Button(this); connect.setText("CONNECT HC-05"); connect.setOnClickListener(v -> pairedDevices());
        header.addView(title,new LinearLayout.LayoutParams(0,-2,1)); header.addView(status); header.addView(connect); root.addView(header,new LinearLayout.LayoutParams(-1,58));
        LinearLayout body = new LinearLayout(this); body.setGravity(Gravity.CENTER); body.setOrientation(LinearLayout.HORIZONTAL);
        joystick = new Joystick(this); body.addView(joystick,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout side = new LinearLayout(this); side.setGravity(Gravity.CENTER); side.setOrientation(LinearLayout.VERTICAL); side.setPadding(12,0,12,0);
        TextView help = new TextView(this); help.setText("DRIVE CONTROL\n\nPush the stick forward, backward or sideways.\n\nRelease to STOP."); help.setTextColor(Color.LTGRAY); help.setTextSize(17); help.setGravity(Gravity.CENTER);
        Button stop = new Button(this); stop.setText("EMERGENCY STOP"); stop.setOnClickListener(v -> { joystick.reset(); send(0,0); });
        side.addView(help); side.addView(stop); body.addView(side,new LinearLayout.LayoutParams(0,-1,0.65f)); root.addView(body,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void pairedDevices() {
        if (adapter == null) { toast("Bluetooth not supported"); return; }
        if (!adapter.isEnabled()) { startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),10); return; }
        Set<BluetoothDevice> set = adapter.getBondedDevices();
        if (set == null || set.isEmpty()) { toast("Pair HC-05 in Android Bluetooth settings first (PIN 1234 or 0000)"); return; }
        final ArrayList<BluetoothDevice> list = new ArrayList<>(set); String[] names = new String[list.size()];
        for(int i=0;i<list.size();i++) names[i]=(list.get(i).getName()==null?"Bluetooth device":list.get(i).getName())+"\n"+list.get(i).getAddress();
        new AlertDialog.Builder(this).setTitle("Select paired HC-05").setItems(names,(d,w)->connect(list.get(w))).setNegativeButton("Cancel",null).show();
    }

    private void connect(final BluetoothDevice device) {
        status.setText("● CONNECTING"); status.setTextColor(Color.YELLOW);
        new Thread(() -> {
            try {
                if(socket!=null) socket.close();
                BluetoothSocket s=device.createRfcommSocketToServiceRecord(SPP); adapter.cancelDiscovery(); s.connect(); socket=s; out=s.getOutputStream(); connected=true;
                runOnUiThread(()->{status.setText("● CONNECTED");status.setTextColor(Color.GREEN);toast("Connected to HC-05");});
            } catch(Exception e) { connected=false; runOnUiThread(()->{status.setText("● DISCONNECTED");status.setTextColor(Color.LTGRAY);toast("Connection failed. Pair HC-05 and retry.");}); }
        }).start();
    }

    private synchronized void send(int left,int right) {
        if(!connected || out==null) return;
        try { out.write((left+","+right+"\n").getBytes("US-ASCII")); out.flush(); }
        catch(Exception e) { connected=false; runOnUiThread(()->status.setText("● DISCONNECTED")); }
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onPause(){super.onPause();send(0,0);}
    @Override protected void onDestroy(){send(0,0);connected=false;try{if(socket!=null)socket.close();}catch(Exception e){}super.onDestroy();}

    private class Joystick extends View {
        Paint p=new Paint(3); float dx=0,dy=0,cx,cy,r;
        Joystick(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        protected void onDraw(Canvas c){super.onDraw(c);cx=getWidth()/2f;cy=getHeight()/2f;r=Math.min(getWidth(),getHeight())*.34f;
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(31,43,61));c.drawCircle(cx,cy,r,p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);p.setColor(Color.rgb(0,220,255));c.drawCircle(cx,cy,r,p);
            p.setStrokeWidth(2);p.setColor(Color.GRAY);c.drawLine(cx-r*.7f,cy,cx+r*.7f,cy,p);c.drawLine(cx,cy-r*.7f,cx,cy+r*.7f,p);
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(0,180,220));c.drawCircle(cx+dx,cy+dy,r*.3f,p);
            p.setTextAlign(Paint.Align.CENTER);p.setTextSize(18);p.setColor(Color.LTGRAY);c.drawText("MOVE",cx,cy+r*1.48f,p);
        }
        public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){float x=e.getX()-cx,y=e.getY()-cy,d=(float)Math.hypot(x,y);if(d>r){x=x*r/d;y=y*r/d;}dx=x;dy=y;invalidate();float forward=-y/r,turn=x/r;int l=Math.round(Math.max(-1,Math.min(1,forward+turn))*255);int rr=Math.round(Math.max(-1,Math.min(1,forward-turn))*255);send(l,rr);return true;}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){reset();return true;}return true;}
        void reset(){dx=0;dy=0;invalidate();send(0,0);}
    }
}
