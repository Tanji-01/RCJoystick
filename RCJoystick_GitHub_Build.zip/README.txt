RC CONTROL - UPGRADED AIDE PROJECT

CONTROLS
- Connect to a previously paired HC-05 module.
- Use the on-screen joystick or press and hold the direction buttons.
- Releasing a direction button or joystick sends STOP.
- Emergency STOP immediately sends 0,0.
- Motor power slider limits the maximum PWM output.

TELEMETRY LIMITATIONS
Battery and wheel speed currently show N/A because the original Arduino Uno + HC-05 + L298N wiring has no battery-voltage divider or wheel encoder/speed sensor. The app cannot measure these values without extra hardware and matching Arduino telemetry code. Wi-Fi is not included: HC-05 is classic Bluetooth SPP, not Wi-Fi or BLE.

BLUETOOTH SETUP
1. Pair HC-05 in Android Bluetooth settings (usually PIN 1234 or 0000).
2. Open app > CONNECT > select the paired HC-05.
3. Test with the car's wheels lifted off the ground first.

ARDUINO WIRING
HC-05 VCC->5V, GND->GND, TXD->D10, RXD->D11 through a voltage divider (protect HC-05 RX from 5V logic).
L298N ENA->D5, IN1->D2, IN2->D3, IN3->D4, IN4->D7, ENB->D6.
Use a suitable separate motor supply. Join motor-driver GND and Arduino GND. Never power motors from the Arduino 5V pin. Remove ENA/ENB jumpers if using PWM pins.

ARDUINO CODE
Upload Arduino_RC_Car.ino to the Uno. The app sends two comma-separated signed motor PWM values followed by newline, e.g. 120,120 or -120,120. The Arduino sketch has a 700ms command timeout failsafe.

BUILD
This is a Java Android project. Open RCJoystick_AIDE in AIDE or push its contents to GitHub and run the included Actions workflow (.github/workflows/build-apk.yml).
