package com.shoaib.rccontroller;

import android.app.*;
import android.os.*;
import android.bluetooth.*;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private OutputStream out;
    private TextView status, speedValue, directionValue;
    private volatile boolean connected = false;
    private volatile int throttle = 180;
    private volatile int leftNow = 0, rightNow = 0;
    private final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private final int BG=Color.rgb(8,13,24), PANEL=Color.rgb(19,29,46), CYAN=Color.rgb(0,210,230), MUTED=Color.rgb(157,174,194);

    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setFlags(1024,1024); adapter=BluetoothAdapter.getDefaultAdapter(); makeUI(); }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void makeUI(){
        LinearLayout root=column();root.setPadding(dp(16),dp(10),dp(16),dp(10));root.setBackgroundColor(BG);
        LinearLayout top=row();TextView title=label("RC  /  CONTROL",23,Color.WHITE);title.setTypeface(null,Typeface.BOLD);top.addView(title,new LinearLayout.LayoutParams(0,dp(42),1));
        status=label("● DISCONNECTED",13,Color.LTGRAY);top.addView(status);Button connect=button("CONNECT",CYAN,Color.BLACK);connect.setOnClickListener(v->pairedDevices());top.addView(connect,new LinearLayout.LayoutParams(dp(125),dp(42)));root.addView(top);
        LinearLayout stats=row();stats.setPadding(0,dp(8),0,dp(8));stats.addView(statCard("BATTERY","N/A","Voltage sensor needed"),new LinearLayout.LayoutParams(0,dp(72),1));stats.addView(statCard("SPEED","N/A","Wheel sensor needed"),new LinearLayout.LayoutParams(0,dp(72),1));stats.addView(statCard("LINK","HC-05","Bluetooth SPP"),new LinearLayout.LayoutParams(0,dp(72),1));root.addView(stats);
        LinearLayout main=row();main.setGravity(Gravity.CENTER);main.setPadding(0,dp(5),0,0);
        LinearLayout drive=column();drive.setGravity(Gravity.CENTER);drive.setBackground(shape(PANEL,18));drive.setPadding(dp(8),dp(8),dp(8),dp(8));
        TextView driveTitle=label("TOUCH JOYSTICK",13,CYAN);driveTitle.setGravity(Gravity.CENTER);drive.addView(driveTitle);
        Joystick stick=new Joystick(this);drive.addView(stick,new LinearLayout.LayoutParams(-1,0,1));main.addView(drive,new LinearLayout.LayoutParams(0,-1,1.2f));
        LinearLayout controls=column();controls.setGravity(Gravity.CENTER);controls.setPadding(dp(14),0,dp(4),0);
        TextView dir=label("DIRECTION  •  READY",13,MUTED);dir.setGravity(Gravity.CENTER);directionValue=dir;controls.addView(dir,new LinearLayout.LayoutParams(-1,dp(30)));
        LinearLayout up=row();up.setGravity(Gravity.CENTER);up.addView(controlButton("▲", "FWD"),new LinearLayout.LayoutParams(dp(92),dp(54)));controls.addView(up);
        LinearLayout mid=row();mid.setGravity(Gravity.CENTER);mid.addView(controlButton("◀", "LEFT"),new LinearLayout.LayoutParams(dp(82),dp(54)));Button stop=button("STOP",Color.rgb(180,55,65),Color.WHITE);stop.setOnClickListener(v->stopAll());mid.addView(stop,new LinearLayout.LayoutParams(dp(92),dp(54)));mid.addView(controlButton("▶", "RIGHT"),new LinearLayout.LayoutParams(dp(82),dp(54)));controls.addView(mid);
        LinearLayout down=row();down.setGravity(Gravity.CENTER);down.addView(controlButton("▼", "BACK"),new LinearLayout.LayoutParams(dp(92),dp(54)));controls.addView(down);
        TextView sl=label("MAX MOTOR POWER",12,MUTED);sl.setPadding(dp(4),dp(12),0,0);controls.addView(sl);
        LinearLayout sr=row();speedValue=label("70%",14,CYAN);sr.addView(speedValue,new LinearLayout.LayoutParams(dp(48),-2));SeekBar seek=new SeekBar(this);seek.setMax(100);seek.setProgress(70);seek.setProgressTintList(android.content.res.ColorStateList.valueOf(CYAN));seek.setThumbTintList(android.content.res.ColorStateList.valueOf(CYAN));seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean u){throttle=Math.max(0,Math.round(p*2.55f));speedValue.setText(p+"%");}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});sr.addView(seek,new LinearLayout.LayoutParams(0,dp(40),1));controls.addView(sr);main.addView(controls,new LinearLayout.LayoutParams(0,-1,1));root.addView(main,new LinearLayout.LayoutParams(-1,0,1));
        TextView foot=label("HC-05 CLASSIC BLUETOOTH  •  RELEASE CONTROL TO STOP",10,MUTED);foot.setGravity(Gravity.CENTER);foot.setPadding(0,dp(8),0,0);root.addView(foot);setContentView(root);
    }
    private View statCard(String name,String value,String note){LinearLayout c=column();c.setGravity(Gravity.CENTER);c.setBackground(shape(PANEL,12));c.setPadding(dp(4),dp(4),dp(4),dp(4));TextView a=label(name,10,MUTED);TextView b=label(value,18,Color.WHITE);b.setTypeface(null,Typeface.BOLD);TextView d=label(note,9,MUTED);c.addView(a);c.addView(b);c.addView(d);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);return c;}
    private Button button(String text,int color,int textColor){Button b=new Button(this);b.setText(text);b.setTextSize(12);b.setTextColor(textColor);b.setAllCaps(false);b.setBackground(shape(color,12));return b;}
    private View controlButton(String glyph,String command){Button b=button(glyph,Color.rgb(34,52,76),Color.WHITE);b.setTextSize(23);b.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){drive(command);return true;}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){stopAll();return true;}return true;});return b;}
    private void drive(String cmd){int p=throttle;int l=0,r=0;if(cmd.equals("FWD")){l=p;r=p;}else if(cmd.equals("BACK")){l=-p;r=-p;}else if(cmd.equals("LEFT")){l=-p;r=p;}else if(cmd.equals("RIGHT")){l=p;r=-p;}leftNow=l;rightNow=r;directionValue.setText("DIRECTION  •  "+cmd);send(l,r);}
    private void stopAll(){leftNow=rightNow=0;directionValue.setText("DIRECTION  •  STOP");send(0,0);}
    private void pairedDevices(){if(adapter==null){toast("This device has no Bluetooth adapter");return;}if(!adapter.isEnabled()){startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),10);return;}Set<BluetoothDevice> set=adapter.getBondedDevices();if(set==null||set.isEmpty()){toast("Pair HC-05 in Android Bluetooth settings first. PIN: 1234 or 0000");return;}final ArrayList<BluetoothDevice> list=new ArrayList<>(set);String[] names=new String[list.size()];for(int i=0;i<list.size();i++)names[i]=(list.get(i).getName()==null?"Bluetooth device":list.get(i).getName())+"\n"+list.get(i).getAddress();new AlertDialog.Builder(this).setTitle("Choose paired HC-05").setItems(names,(d,w)->connect(list.get(w))).setNegativeButton("Cancel",null).show();}
    private void connect(final BluetoothDevice device){status.setText("● CONNECTING");status.setTextColor(Color.YELLOW);new Thread(()->{try{if(socket!=null)socket.close();BluetoothSocket s=device.createRfcommSocketToServiceRecord(SPP);adapter.cancelDiscovery();s.connect();socket=s;out=s.getOutputStream();connected=true;runOnUiThread(()->{status.setText("● CONNECTED");status.setTextColor(Color.GREEN);toast("Connected to "+device.getName());});}catch(Exception e){connected=false;runOnUiThread(()->{status.setText("● DISCONNECTED");status.setTextColor(Color.LTGRAY);toast("Connection failed. Check pairing and retry.");});}}).start();}
    private synchronized void send(int left,int right){if(!connected||out==null)return;try{out.write((left+","+right+"\n").getBytes("US-ASCII"));out.flush();}catch(Exception e){connected=false;runOnUiThread(()->{status.setText("● DISCONNECTED");status.setTextColor(Color.LTGRAY);});}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onPause(){super.onPause();stopAll();}
    @Override protected void onDestroy(){stopAll();connected=false;try{if(socket!=null)socket.close();}catch(Exception e){}super.onDestroy();}
    private class Joystick extends View{Paint p=new Paint(3);float dx=0,dy=0,cx,cy,r;Joystick(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}protected void onDraw(Canvas c){super.onDraw(c);cx=getWidth()/2f;cy=getHeight()/2f;r=Math.max(20,Math.min(getWidth(),getHeight())*.34f);p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(31,43,61));c.drawCircle(cx,cy,r,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(CYAN);c.drawCircle(cx,cy,r,p);p.setStrokeWidth(1);p.setColor(Color.GRAY);c.drawLine(cx-r*.7f,cy,cx+r*.7f,cy,p);c.drawLine(cx,cy-r*.7f,cx,cy+r*.7f,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(0,180,220));c.drawCircle(cx+dx,cy+dy,r*.3f,p);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(dp(13));p.setColor(MUTED);c.drawText("MOVE",cx,cy+r*1.5f,p);}
        public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){float x=e.getX()-cx,y=e.getY()-cy,d=(float)Math.hypot(x,y);if(d>r){x=x*r/d;y=y*r/d;}dx=x;dy=y;invalidate();float f=-y/r,t=x/r;int l=Math.round(Math.max(-1,Math.min(1,f+t))*throttle);int rr=Math.round(Math.max(-1,Math.min(1,f-t))*throttle);leftNow=l;rightNow=rr;send(l,rr);directionValue.setText("DIRECTION  •  JOYSTICK");return true;}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){dx=dy=0;invalidate();stopAll();return true;}return true;}}
}
